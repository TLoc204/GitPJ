package com.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
